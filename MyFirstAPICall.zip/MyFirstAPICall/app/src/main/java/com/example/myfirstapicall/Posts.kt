package com.example.myfirstapicall

import android.se.omapi.Session
import com.google.gson.annotations.SerializedName

data class Posts(var userId: Int, var id: Int = 0, var title: String, var body: String)


data class Candidate(
    var username: String,
    var password: String,
    var first_name: String,
    var last_name: String,
    var email: String
)

data class CandidateResponse(
    var id: Int,
    var username: String,
    var password: String,
    var first_name: String,
    var last_name: String,
    var email: String
)


data class TestSession(
    var candidate: Int
)


data class TestSessionResponse(
    var id: Int,
    var candidate: Int,
    var session_key: String
)


data class GetChallengeResponse(
    var id: Int,
    var question_text: String,
    var test_input: testInput,
    var sample_input: sampleInput,
    var sample_output: sampleOutput
)


data class PostAnswer(
    var test_session: Int,
    var output: Output,
    var challenge: Int
)


data class testInput(var text:String)

data class sampleInput(var text:String)

data class sampleOutput(var count:String)

data class Output(var list:List<Int>)

data class VowelCount(var a:Int,var e:Int, var i:Int,var o:Int,var u:Int)
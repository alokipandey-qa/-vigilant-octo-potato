package com.example.myfirstapicall

import com.google.gson.annotations.SerializedName

data class MyFirstResponse(@SerializedName("userId") var userId: Int=0, var id: Int=0, var title: String="", var completed: String="")
package com.example.myfirstapicall

import org.json.JSONArray
import org.json.JSONObject

interface NetworkCallBackListener {

    fun  onShowProgress()
     fun onCompleted(response : String)
}

interface FlagPost{
    fun onCompleted(flag:Boolean)
}
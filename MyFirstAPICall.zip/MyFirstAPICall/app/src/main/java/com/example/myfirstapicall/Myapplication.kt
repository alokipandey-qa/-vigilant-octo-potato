package com.example.myfirstapicall

import android.app.Application

class Myapplication : Application() {


    companion object {

        private var myapplication : Myapplication?=null
        var myCounter=0

        /*fun setMyCounter(i: Int){

        }*/

       fun  getInstance(): Myapplication? {
           return myapplication
        }
    }
    override fun onCreate() {
        super.onCreate()
        myapplication=this

    }
}
package com.example.myfirstapicall

import android.os.Bundle
import android.util.Base64
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_async_test.*
import okhttp3.Credentials
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class MyAsyckTestActivity : AppCompatActivity() {
    var flag = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_async_test)

        /*button.setOnClickListener {
            startActivity(Intent(this,MainActivity::class.java))
        }*/

        var candidate_id = -1
        var testSession = ""
        var challengeId = -1
        var output: String = answer.text.toString()
        val authorization = Credentials.basic("alokipandey", "devLabs")


        register_candidate.setOnClickListener {
            candidate_id = registerCandidate()
        }

        create_session.setOnClickListener {
            testSession = createTestSession(candidate_id)
        }

        fetch_question.setOnClickListener {
            challengeId = getChallenge(authorization, object : FlagPost {
                override fun onCompleted(flag: Boolean) {
                    /*if (flag) postAnswer(
                        challenge = challengeId,
                        testSession = testSession,
                        output = output,
                        auth = authorization
                    )*/
                }
            })
        }

        submit.setOnClickListener {
            challengeId = getChallenge(authorization, object : FlagPost {
                override fun onCompleted(flag: Boolean) {
                    if (flag) postAnswer(
                        challenge = challengeId,
                        testSession = testSession,
                        output = output,
                        auth = authorization
                    )
                }
            })
            /*postAnswer(
                challenge = challengeId,
                testSession = testSession,
                output = output,
                auth = authorization
            )*/
        }
    }

    fun registerCandidate(): Int {
        var id = 0
        val candidate = Candidate(
            username = "alokipandey",
            password = "devLabs",
            first_name = "Alok",
            last_name = "Pandey",
            email = "alok.pandey@qainfotech.com"
        )
        retrofitRegisterApi.retrofitService.register(candidate, "api/v1/candidates/")
            .enqueue(object : Callback<CandidateResponse> {

                override fun onFailure(call: Call<CandidateResponse>, t: Throwable) {
                    Toast.makeText(
                        this@MyAsyckTestActivity,
                        "Failed onFailure",
                        Toast.LENGTH_LONG
                    ).show()
                    question.append(t.message + "\n\n")
                }

                override fun onResponse(
                    call: Call<CandidateResponse>,
                    response: Response<CandidateResponse>
                ) {
                    if (!response.isSuccessful) {
                        Toast.makeText(
                            this@MyAsyckTestActivity,
                            "Failed onResponse",
                            Toast.LENGTH_LONG
                        ).show()
                        question.text = response.code().toString()
                    } else {
                        Toast.makeText(
                            this@MyAsyckTestActivity,
                            "Success",
                            Toast.LENGTH_SHORT
                        ).show()
                        val candidateResponse: CandidateResponse = response.body()!!
                        Log.d("onResponse_else", response.body().toString())
                        var content = ""
                        content += "ID: " + candidateResponse.id + "\n"
                        content += "username: " + candidateResponse.username + "\n"
                        content += "password: " + candidateResponse.password + "\n"
                        content += "first_name: " + candidateResponse.first_name + "\n\n"
                        content += "last_name: " + candidateResponse.last_name + "\n\n"
                        content += "email: " + candidateResponse.email + "\n\n\n"

                        question.append(content)
                        id = candidateResponse.id
                    }
                }
            })
        return id
    }


    fun createTestSession(candidate: Int): String {
        val testSession = TestSession(121)
        var sessionID = ""

        retrofitRegisterApi.retrofitService.getTestSession(testSession, "api/v1/testsessions/")
            .enqueue(object : Callback<TestSessionResponse> {
                override fun onFailure(call: Call<TestSessionResponse>, t: Throwable) {
                    Toast.makeText(
                        this@MyAsyckTestActivity,
                        "Failed onFailure",
                        Toast.LENGTH_LONG
                    ).show()
                    question.append(t.message + "\n\n")
                }

                override fun onResponse(
                    call: Call<TestSessionResponse>,
                    response: Response<TestSessionResponse>
                ) {
                    if (!response.isSuccessful) {
                        Toast.makeText(
                            this@MyAsyckTestActivity,
                            "Failed onResponse",
                            Toast.LENGTH_LONG
                        ).show()
                        question.append(response.code().toString())
                    } else {
                        Toast.makeText(
                            this@MyAsyckTestActivity,
                            "Success",
                            Toast.LENGTH_SHORT
                        ).show()
                        val testSessionResponse: TestSessionResponse = response.body()!!
                        Log.d("onResponse_else", response.body().toString())
                        var content = ""
                        content += "ID: " + testSessionResponse.id + "\n"
                        content += "username: " + testSessionResponse.candidate + "\n"
                        content += "password: " + testSessionResponse.session_key + "\n\n\n"

                        question.append(content)
                        sessionID = testSessionResponse.session_key
                    }
                }
            })
        return sessionID

    }

    companion object {
        var base64 = ""
    }


    fun getChallenge(authorization: String, flagPost: FlagPost): Int {
        var challengeId = -1

        var username = "alokipandey"
        var password = "devLabs"

        val plainString = "$username:$password"
        val data: ByteArray = plainString.toByteArray()
        base64 = Base64.encodeToString(data, Base64.NO_WRAP)
//        base64 ="YWxva2lwYW5kZXk6ZGV2TGFicw=="
        Log.d("base64", base64)

        retrofitRegisterApi.retrofitService.getChallenge(
            "api/v1/challenges/get_challenge/",
            authorization
        ).enqueue(object : Callback<GetChallengeResponse> {
            override fun onFailure(call: Call<GetChallengeResponse>, t: Throwable) {
                Toast.makeText(
                    this@MyAsyckTestActivity,
                    "Failed onFailure",
                    Toast.LENGTH_LONG
                ).show()
                question.append(t.message + "\n\n")
            }

            override fun onResponse(
                call: Call<GetChallengeResponse>,
                response: Response<GetChallengeResponse>
            ) {
                if (!response.isSuccessful) {
                    Toast.makeText(
                        this@MyAsyckTestActivity,
                        "Failed onResponse",
                        Toast.LENGTH_LONG
                    ).show()
                    question.append(response.code().toString())
                } else {
                    Toast.makeText(
                        this@MyAsyckTestActivity,
                        "Success",
                        Toast.LENGTH_SHORT
                    ).show()
                    val getChallengeResponse: GetChallengeResponse = response.body()!!
                    Log.d("onResponse_else", response.body().toString())
                    var content = ""
                    content += "ID: " + getChallengeResponse.id + "\n"
                    content += "question_text: " + getChallengeResponse.question_text + "\n"
                    content += "test_input: " + getChallengeResponse.test_input + "\n"
                    content += "sample_input: " + getChallengeResponse.sample_input + "\n"
                    content += "sample_output: " + getChallengeResponse.sample_output + "\n\n\n"
                    question.append(content)
                    challengeId = getChallengeResponse.id
                    flagPost.onCompleted(true)
                }
            }
        })
        flag = true
        return challengeId
    }


    fun postAnswer(testSession: String, challenge: Int, output: String, auth: String) {

        /*val count  = HashMap<Char,Int>()
        count.put('a',1)
        count.put('e',3)
        count.put('i',1)
        count.put('o',4)
        count.put('u',1)

        val countv  = VowelCount(1,3,1,4,1)*/


        var count = listOf(9,3,1,8,4,5,0)



        val answer = PostAnswer(
            test_session = 113,
            output = Output(count),
            challenge = 5
        )
        //CoroutineScope

        retrofitRegisterApi.retrofitService.postAnswer(
            answer,
            "api/v1/testsessionchallenges/output/", auth
        ).enqueue(object : Callback<String> {
            override fun onFailure(call: Call<String>, t: Throwable) {
                Toast.makeText(
                    this@MyAsyckTestActivity,
                    "Failed onFailure",
                    Toast.LENGTH_LONG
                ).show()
                question.append(t.message + "\n\n")
            }

            override fun onResponse(call: Call<String>, response: Response<String>) {
                if (!response.isSuccessful) {
                    Toast.makeText(
                        this@MyAsyckTestActivity,
                        "Failed onResponse",
                        Toast.LENGTH_LONG
                    ).show()
                    question.append(
                        response.code().toString() + "\n" + response.headers() + "\n" + response.errorBody().toString() + "\n\n"
                    )
                } else {
                    Toast.makeText(
                        this@MyAsyckTestActivity,
                        "Success",
                        Toast.LENGTH_SHORT
                    ).show()
                    /*val getChallengeResponse: GetChallengeResponse = response.body()!!
                    Log.d("onResponse_else", response.body().toString())
                    var content = ""
                    content += "ID: " + getChallengeResponse.id + "\n"
                    content += "question_text: " + getChallengeResponse.question_text + "\n"
                    content += "test_input: " + getChallengeResponse.test_input + "\n"
                    content += "sample_input: " + getChallengeResponse.sample_input + "\n"
                    content += "sample_output: " + getChallengeResponse.sample_output + "\n\n\n"*/
                    question.append(response.code().toString() + "\n\n")
                }
            }
        })
    }

}

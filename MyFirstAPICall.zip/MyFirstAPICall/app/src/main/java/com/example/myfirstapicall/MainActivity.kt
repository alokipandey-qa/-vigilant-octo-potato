package com.example.myfirstapicall

import android.os.Bundle
import android.os.PersistableBundle
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_main.*
import java.net.URL


class MainActivity : AppCompatActivity(){
    lateinit var fetchAPIAsyncTask:FetchAPI

    lateinit var textView: TextView
    override fun onSaveInstanceState(outState: Bundle?, outPersistentState: PersistableBundle?) {
        super.onSaveInstanceState(outState, outPersistentState)

    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)
        textView= findViewById(R.id.responseTextView)
        Log.d("TAGTAG","onCreate texview ${textView}.")

        fetchAPIAsyncTask = FetchAPI(object : NetworkCallBackListener{
            override fun onShowProgress() {
//                Toast.makeText(this@MainActivity, "Fetching...", Toast.LENGTH_LONG).show();
//                showProgressDialog("Loading your data...")
            }
            override fun onCompleted(response: String) {
//                hideProgressDialog()
//                Log.d("TAGTAG","onPostExecute")

                //showAlokToast("Response... ${response.optJs("userId")}")
//                val parseData = parseData(response)
                /* var count =0
                 val get = response.optJSONObject(1).optString("UserID")
                 for (i in 0 until response.length()){
                     if(response.getJSONObject(i).optString("gender") == "Male") count+=1
                 }*/
//                showAlokToast("#Male : $count")
//                    textView.text=""+Myapplication.myCounter
                Log.d("TAGTAG","onCompleted texview ${textView}.")
                Log.d("TAGTAG","onCompleted $response")
//                    textView.text=response
                finish()

//                Myapplication.myCounter=Myapplication.myCounter+1
//                showAlokToast("parseData?.userId : ${parseData?.userId} ")
                //val tvw = findViewById<TextView>(R.id.response)
                //tvw.text= parseData?.userId.toString()
            }
        },++Myapplication.myCounter,textView)
        showResult(fetchAPIAsyncTask)
        /*fetch.setOnClickListener {
            showResult(fetchAPIAsyncTask)
        }*/
    }


    private fun showResult(fetchAPIAsyncTask: FetchAPI) {
       fetchAPIAsyncTask.execute(URL(Constants.sample_url_2))
//        Log.d("ResponseJSON",""+json.javaClass.name)
//        json.javaClass.name



        /*val url = URL("https://ankitkotnalaqait.github.io/dummydata/data.json")
        val connection: HttpURLConnection = url.openConnection() as HttpURLConnection
        connection.connect()
        val inputStream = connection.getInputStream()

        val reader = BufferedReader(InputStreamReader(inputStream))

        val buffer = StringBuffer()

        while (reader.readLine() != null) {
            buffer.append(reader.readLine() + "\n");
            Log.d("Response: ", reader.readLine());
        }
        inputStream.close()
*/
    }



    private fun parseData(res: String): MyFirstResponse? {
        val gson = Gson()
        val fromJson = gson.fromJson<MyFirstResponse>(res, MyFirstResponse::class.java)
        return fromJson
    }



    override fun onDestroy() {
//        fetchAPIAsyncTask.cancel(true)
//        hideProgressDialog()
        System.gc()
        System.gc()
        System.gc()
        System.gc()
        System.gc()
        Log.d("TAGTAG","onDestroy texview ${textView}.")
        super.onDestroy()
    }
}

package com.example.myfirstapicall

import retrofit2.Call
import retrofit2.http.*


interface ApiService {

/*    @GET("/{id}")
    fun getQuestion(@Path("id") endPoint: String): Call<List<Posts>>

    @POST("/{id}")
    fun postAnswer(@Body post: Posts, @Path("id") endPoint: String): Call<Posts>*/


    @POST("{id}")
    fun register(@Body candidate: Candidate,@Path("id") endPoint: String): Call<CandidateResponse>

    @POST("{id}")
    fun getTestSession(@Body test: TestSession,@Path("id") endPoint: String): Call<TestSessionResponse>

//    @Headers("Authorization","Basic "+MyAsyckTestActivity.base64)

    @GET("{id}")
    fun getChallenge(@Path("id") endPoint: String, @Header("Authorization")authorization:String): Call<GetChallengeResponse>

    @POST("{id}")
    fun postAnswer(@Body answer: PostAnswer,@Path("id") endPoint: String, @Header("Authorization")authorization:String): Call<String>


}

package com.example.myfirstapicall

//import jdk.nashorn.internal.parser.JSONParser
import android.os.AsyncTask
import android.os.Handler
import android.util.Log
import android.widget.TextView
import org.json.JSONArray
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL


class FetchAPI(
    var networkCallBackListener: NetworkCallBackListener,
    val counter:Int,
    val textView: TextView
) : AsyncTask<URL, Int, String>() {
    override fun onPreExecute() {
        super.onPreExecute()
        Log.d("TAGTAG","onPreExecute")
        networkCallBackListener.onShowProgress()
        //networkCallBackListener.onShowProgress()
    }

    override fun doInBackground(vararg params: URL?): String {
        //val url = "https://ankitkotnalaqait.github.io/dummydata/data.json"
        //val url = URL("https://ankitkotnalaqait.github.io/dummydata/data.json")
        //val urlConnection: HttpURLConnection = url.openConnection() as HttpURLConnection
        //val url: URL? = params[0]
        Log.d("TAGTAG","doInBackground init")

        val connection: HttpURLConnection = params[0]?.openConnection() as HttpURLConnection
        connection.connect()
        //var stream = connection.getInputStream()
        val reader = BufferedReader(InputStreamReader(connection.inputStream,"UTF-8"))
        //Log.d("class:tag",""+reader.javaClass.name)
        val buffer = StringBuffer()
        //Log.d("class:tag",""+buffer.toString().javaClass.name)
        var line: String?
        //Handler().postDelayed(Runnable {
            do{
                line = reader.readLine()
                if(line==null)break
                buffer.append(line)}
            while (true)
       // },5000)


//        if ((line="")==null)
        /*
        while ((line =reader.readLine()) != null) {
            buffer.append(reader.readLine());
            Log.d("Response: ", "> ");
        }
*/
        Log.d("Response: ", "> $buffer ");

//        val jSONObject = JSONArray(buffer.toString())
        Thread.sleep(4000)
        Log.d("TAGTAG","doInBackground finished")

        return buffer.toString()
        //return
    }

    override fun onPostExecute(result: String) {
        super.onPostExecute(result)
        Log.d("TAGTAG","onPostExecute $textView")
        textView.text=result
        networkCallBackListener.onCompleted(counter.toString())
    }
}
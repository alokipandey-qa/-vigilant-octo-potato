package com.example.myfirstapicall

data class JsonData(val mail:String,val name:String)
package com.example.myfirstapicall

import java.net.URL

class Constants {

companion object {

    val sample_url = "https://ankitkotnalaqait.github.io/dummydata/data.json"
    val sample_url_2 = "https://jsonplaceholder.typicode.com/todos/1"
}
}
package com.example.myfirstapicall

import android.app.ProgressDialog
import android.content.Context
import android.widget.Toast

fun Context.showAlokToast(msg : String){
    Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}




var progressDialog: ProgressDialog?=null
fun Context.showProgressDialog(msg: String){
    if(progressDialog ==null)
    progressDialog = ProgressDialog(this)
    progressDialog?.setTitle("Please wait")
    progressDialog?.setMessage(msg)
    progressDialog?.setCancelable(true)
    progressDialog?.show()
}

fun Context.hideProgressDialog(){
    if (progressDialog!=null) progressDialog?.hide()
}
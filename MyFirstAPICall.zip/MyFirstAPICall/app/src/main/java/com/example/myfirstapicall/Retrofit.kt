package com.example.myfirstapicall

import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.converter.scalars.ScalarsConverterFactory
import retrofit2.http.GET

/*private const val BASE_URL = " https://android-kotlin-fun-mars-server.appspot.com/"

private const val BASE_URL2 = "https://jsonplaceholder.typicode.com/"

private const val BASE_URL3 = " https://android-kotlin-fun-mars-server.appspot.com/"*/


private const val BASE_URL = "https://code-riddler.herokuapp.com/"
//private const val REGISTER_CANDIDATE = "https://code-riddler.herokuapp.com/"
/*private const val CREATE_TEST_SESSION = "https://code-riddler.herokuapp.com/"
private const val GET_CHALLENGE = "https://code-riddler.herokuapp.com/"
private const val POST_OUTPUT = "https://code-riddler.herokuapp.com/"*/


/*
private val retrofit = Retrofit.Builder()
    .addConverterFactory(ScalarsConverterFactory.create())
    .baseUrl(BASE_URL2)
    .build()
*/

/*
private val retrofitRegister = Retrofit.Builder()
    .addConverterFactory(GsonConverterFactory.create())
    .baseUrl(REGISTER_CANDIDATE)
    .build()

private val retrofitTestSession = Retrofit.Builder()
    .addConverterFactory(GsonConverterFactory.create())
    .baseUrl(CREATE_TEST_SESSION)
    .build()

private val retrofitGetChallenge = Retrofit.Builder()
    .addConverterFactory(GsonConverterFactory.create())
    .baseUrl(GET_CHALLENGE)
    .build()

private val retrofitPostOutput = Retrofit.Builder()
    .addConverterFactory(GsonConverterFactory.create())
    .baseUrl(POST_OUTPUT)
    .build()
*/


private val retrofitClient = Retrofit.Builder()
    .addConverterFactory(GsonConverterFactory.create())
    .baseUrl(BASE_URL)
    .build()


object retrofitRegisterApi {
    val retrofitService: ApiService by lazy {
        retrofitClient.create(ApiService::class.java)
    }
}
/*
object retrofitTestSessionApi {
    val retrofitService: ApiService by lazy {
        retrofitClient.create(ApiService::class.java)
    }
}

object retrofitGetChallengeApi {
    val retrofitService: ApiService by lazy {
        retrofitClient.create(ApiService::class.java)
    }
}

object retrofitPostOutputApi {
    val retrofitService: ApiService by lazy {
        retrofitClient.create(ApiService::class.java)
    }*/

